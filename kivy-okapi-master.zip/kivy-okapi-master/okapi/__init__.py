"""Package for Okapi"""

__project__ = "okapi"
__version__ = "0.1.1"

VERSION = __project__ + '-' + __version__
